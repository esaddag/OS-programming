#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <windows.h>


typedef struct
{
	int threadNo;
	int* item_counter;
	int processNo;
}THREAD_PARAMETERS;


DWORD WINAPI threadWork(LPVOID parameters);

int main(int argc, char* argv[])
{
	HANDLE* handles;
	THREAD_PARAMETERS* lpParameter;
	int* threadID;
	int i = 0;
	int threadCount = 4;//number of process for each thread

	// check error in child process
	if (argc != 2)
	{
		printf("error in child process...now exiting %s\n", argv[0]);
		system("pause");
		exit(0);
	}


	//memory allocation for handles, thread parameter and threadID's 
	handles = malloc(sizeof(HANDLE)* threadCount);
	lpParameter = malloc(sizeof(THREAD_PARAMETERS)* threadCount);
	threadID = malloc(sizeof(int)* threadCount);

	for (i = 0; i < threadCount; i++)
	{
		//initialize parameters
		lpParameter[i].threadNo = i + 1;
		lpParameter[i].processNo = atoi(argv[1]);

		//create thread
		handles[i] = CreateThread(NULL, 0, threadWork, &lpParameter[i], 0, &threadID[i]);


		//check errors in creation
		if (handles[i] == INVALID_HANDLE_VALUE)
		{
			printf("error when creating thread\n");
			system("pause");
			exit(0);
		}	
	}

	
	WaitForMultipleObjects(threadCount, handles, TRUE, INFINITE);

	
		//day number which is same to process number
		int day_no = lpParameter[1].processNo;


		//print day and number of items
		printf("#START DAY %d#\n",day_no);
		printf("%d MILK, %d BISCUIT, %d CHIPS, %d COKE\n", (int)lpParameter[0].item_counter, (int)lpParameter[1].item_counter, (int)lpParameter[2].item_counter, (int)lpParameter[3].item_counter);

		//free allocated memory
		free(handles);
		free(lpParameter);
		free(threadID);


		system("pause");
		return 1;
	}



DWORD WINAPI threadWork(LPVOID parameters)
{
	THREAD_PARAMETERS* param = (THREAD_PARAMETERS*)parameters;

	int i = 0;
	int counter = 0;//to count the number of one object
	int x = (param->threadNo);//to find the which object to count
	int y = (param->processNo);//to find the which day to count
	char buf[100];
	char item_name[15];
	FILE *ptr_file;
	
	boolean enter = FALSE;//to check entered the day or not

	//opening file and check error
	fopen_s(&ptr_file, "market.txt", "r");
	if (!ptr_file)
	{
		return 1;
	}

	//creeating a string for find the beginning of each day
	char startDay[20];
	sprintf_s(startDay, 20, "#START DAY %d#\n", y);

	//creeating a string for find the beginning of each day
	char endDay[20];
	sprintf_s(endDay, 20, "#END DAY %d#\n", y);

	//if checking thread no to know which object will count
	//four number, four object
	if (x == 1)
	{
		strncpy_s(item_name, 15, "MILK", 10);
	}
	else if (x == 2)
	{
		strncpy_s(item_name, 15, "BISCUIT", 10);
	}
	else if (x == 3)
	{
		strncpy_s(item_name, 15, "CHIPS", 10);
	}
	else if (x == 4)
	{
		strncpy_s(item_name, 15, "COKE", 10);
	}


	//checking buffer if it is start of the day of this process
	//if it is then assign TRUE to enter value
	while (fgets(buf, 100, ptr_file) != NULL)
	{
		if (strstr(buf, startDay))
		{
			enter = TRUE;
		}
		if (enter)
		{
			if (strstr(buf, item_name) != NULL)
			{
				counter++;
			}
			else if (strstr(buf, endDay))//checking buffer if it is end of the day of this process, if it is then assign TRUE to enter value
			{
				enter = FALSE;
			}
		}

	}

	param->item_counter = counter;//assagn the counter value to parameter
	return 1;


}


