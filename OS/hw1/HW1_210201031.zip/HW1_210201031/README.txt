Muhammed Esad DA�
210201031

File->New->Project
Empty Project
Name:Homework->OK

Right Click on "Homework" project on Solution Explorer
Add->New Item
C++ File
Name:Parent.c->OK

Right Click on "Solution 'Homework'" project on Solution Explorer
Add->New Project
Empty Project
Name:Child->OK

Right Click on "Child" project on Solution Explorer
Add->New Item
C++ File
Name:Child.c->OK

Right Click on "Homework" project on Solution Explorer
Select "Set as a startup project"

Copy Parent.c into Visual Studio's Parent.c
Copy Child.c into Visual Studio's Child.c

Copy market.txt to same folder with Parent.c of Visual Studio

Build and run.